This documentation has been started because we needed some place to put our
design, research & development related notes collected collected while hacking
on this project. The official suds project documentation has not been included
in this fork, as it was not stored in the same repository as the original
project's code base.

Once official suds project documentation has been integrated into this fork,
parts of this documentation that start getting some well rounded form, should be
integrated into the official project documentation.
